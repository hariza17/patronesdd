from singleton.logger import Logger

logger_object = Logger()
logger_object.file_name = "nova.log"


logger_object.info("Holllllaaaalalal")
logger_object.info("23232")
logger_object.error("23232")


logger_object2= Logger()

logger_object2.info("Holeeellllaaaalalal")
logger_object2.info("23eeee232")
logger_object2.error("23eee232")